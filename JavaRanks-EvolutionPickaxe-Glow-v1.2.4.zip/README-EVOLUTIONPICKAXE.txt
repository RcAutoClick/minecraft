EvolutionPickaxe Resource Pack v1.2.4 - Minecraft 26.3

Este pacote junta o Java Ranks com o glow emissivo da habilidade Lanterna.

Glow por material:
- Madeira: âmbar/quente
- Pedra: cinza/branco
- Ferro: branco/prateado
- Ouro: amarelo/dourado
- Diamante: ciano
- Netherite: roxo/cinza
- Cobre: cobre/laranja

Mudança v1.2.4:
- O modelo antigo de cubos/extrusão foi substituído por uma camada de contorno emissiva de alta resolução (128x128).
- O contorno acompanha a silhueta inteira da picareta e evita os rasgos/buracos do modelo 3D anterior.
- CustomModelData usa uma janela exata por material, evitando que outros CMDs ativem o glow por acidente.
- Picaretas dropadas com Lanterna ativa continuam usando o modelo de glow; o plugin mantém a luz dinâmica junto do item.
