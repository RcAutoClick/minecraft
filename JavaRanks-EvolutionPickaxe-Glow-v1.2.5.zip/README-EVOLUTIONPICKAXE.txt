EvolutionPickaxe Resource Pack v1.2.4 - Minecraft 26.3

Este pacote junta o Java Ranks com o glow emissivo da habilidade Lanterna.

Glow por material:
- Madeira: âmbar/quente
- Pedra: cinza/branco
- Ferro: branco/prateado
- Ouro: amarelo/dourado
- Diamante: ciano
- Netherite: roxo/cinza
- Cobre: cobre/laranja

Mudança v1.2.4:
- O modelo antigo de cubos/extrusão foi substituído por uma camada de contorno emissiva de alta resolução (128x128).
- O contorno acompanha a silhueta inteira da picareta e evita os rasgos/buracos do modelo 3D anterior.
- CustomModelData usa uma janela exata por material, evitando que outros CMDs ativem o glow por acidente.
- Picaretas dropadas com Lanterna ativa continuam usando o modelo de glow; o plugin mantém a luz dinâmica junto do item.


Glow v1.2.5
- Outline rebuilt from the real pickaxe silhouette.
- Thin 3-stage contour: pale inner rim + saturated glow + subtle dark halo.
- No large 2D extrusion.
- Diamond uses the pink/lilac reference style requested.
- Wood/stone/iron/gold/netherite/copper keep the same contour geometry with material-matched colors.
- Existing CustomModelData values and plugin integration are unchanged.
