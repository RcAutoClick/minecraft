EvolutionPickaxe Resource Pack v1.2.3 - Minecraft 26.3

Este pacote junta o Java Ranks com o glow emissivo da habilidade Lanterna.

Glow por material:
- Madeira: âmbar/quente
- Pedra: cinza/branco
- Ferro: branco/prateado
- Ouro: amarelo/dourado
- Diamante: ciano
- Netherite: roxo/cinza
- Cobre: cobre/laranja

O plugin aplica modelos temporários somente enquanto a picareta realmente está iluminando.
Picaretas dropadas com Lanterna ativa também mantêm glow + luz dinâmica.
