Correção para Minecraft Java 26.3.
- pack.mcmeta atualizado para Resource Pack 97.1.
- removido supported_formats antigo/inválido para packs modernos.
- item.fsh atualizado para a estrutura de shaders/OIT do 26.3.
- CustomModelData 910001 continua sendo o modelo da picareta com glow da Lanterna.
