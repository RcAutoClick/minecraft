Java Ranks + EvolutionPickaxe Glow

- Mantém as texturas/fontes do java-ranks.
- Adiciona somente os assets necessários para o glow da DIAMOND_PICKAXE.
- O plugin EvolutionPickaxe v1.2.2 aplica CustomModelData 910001 apenas enquanto Lanterna estiver ativa.
- Ao desligar Lanterna ou trocar de item, o plugin restaura o CustomModelData anterior.
- O plugin também remove o glint falso de encantamento usado pela versão 1.2.1.
